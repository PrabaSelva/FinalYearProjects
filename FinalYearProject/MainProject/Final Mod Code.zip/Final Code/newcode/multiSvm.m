function [out] = multiSvm(TestSet)
load f1
load f2
load f3
load f4
load f6
load f7
load f9
load f10
load f11
load f12
load f13
load f14
load f16
load f17
GroupTrain=[1 1 1 1 1 1 2 2 2 2 2 3 3 3];
TrainingSet=[feat1 feat2 feat3 feat4  feat6 feat7 feat9 feat10 feat11 feat12 feat13 feat14 feat16 feat17];
u=unique(GroupTrain);
numClasses=length(u);
for k=1:numClasses
    G1vAll=(GroupTrain==u(k));
    models(k) = svmtrain(TrainingSet,G1vAll);
    
end
comp=[];
for n=1:length(TrainingSet)
  
    sem=cvEucdist((TrainingSet(1,n)),TestSet);
    comp=[comp sem];
   
end
result = (find(comp==min(comp)));
out=GroupTrain(result);