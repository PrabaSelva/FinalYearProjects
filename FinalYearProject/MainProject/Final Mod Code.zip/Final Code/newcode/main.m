clc;
clear all;
close all;

%Image Acquisition
[aa bb]=uigetfile('.jpg');
I=imread([bb aa]);
figure,imshow(I);
title('Input Image');

%Pre Processing
I1=imresize(I,[256 256]);
figure,imshow(I1);
title('Resized Image');

%Adding Noise
In=imnoise(I1,'salt & Pepper');
figure,imshow(In);
title('Noisy Image');

%Noise Removal
%ADDING NOISE
In=imnoise(I1,'salt & pepper');
figure,imshow(In)
title('Salt&Peper')

%NOISE REMOVAL
J=In;
winsz=3;
[s1, s2]=size(In);
sz=min([s1 s2]);
p=(winsz-1)/2;
if size(J,3)>1
for mnpk=1:3
    ipnoise=J(:,:,mnpk);
medop=padarray(ipnoise,[p p]);
for i=1+p:sz+p
    for j=1+p:sz+p
        submed=medop(i-p:i+p,j-p:j+p);
        medop(i,j)=median(submed(1:9));
    end
    end

medop=medop(1+p:sz+p,1+p:sz+p);
 op1(:,:,mnpk)=medop;
end
else
   ipnoise=J;
medop=padarray(ipnoise,[p p]);
for i=1+p:sz+p
    for j=1+p:sz+p
        submed=medop(i-p:i+p,j-p:j+p);
        medop(i,j)=median(submed(1:9));
    end
    end

medop=medop(1+p:sz+p,1+p:sz+p);
op1=medop;
end 
figure,imshow(op1);
title('Noise removal image')

contrast enhancement
im=I1;
if size(J,3)>1
J = adapthisteq(rgb2gray(im));
else
    J = adapthisteq(im);
end  
figure, imshow(J);
title('Contrast Enhanced Image');


%SLIC Segmentation
I=I1;
m=15;
k=50;
seRadius=1.5;
colopt='median';
[l, Am, Sp, d] = seg(I, k, m, seRadius, colopt);
figure,imshow(l,[]);
title('Pixel Index');
figure,imshow(d,[]);
impixelinfo
figure,imshow(drawregionboundaries(l, I, [255 255 255]))
title('SLIC Segmentation');
Ig=rgb2gray(I);
SE = strel('octagon',3);
img2_imclose= imclose(Ig,SE); 
impixelinfo
for i=1:256
    for j=1:256
        if (img2_imclose(i,j)>180)
            A(i,j)=1;
        else
            A(i,j)=0;
        end
    end
end
 A=bwareaopen(A,10);
figure,imshow(A);
title('segmented part');
% gabor feature extraction

[gaborSquareEnergy, gaborMeanAmplitude] = phasesym(A)

GSE= mean(gaborSquareEnergy);
GMA=mean(gaborMeanAmplitude);
feat=mean([GSE GMA])
% save f17 feat17

% classification by svm

outs= multiSvm(feat)
if outs==1
    msgbox('Cloud');
    % segmentation
im=I1;
[lb,center] = adaptcluster_kmeans(im(:,:,1));
figure,imshow(lb,[]);
impixelinfo

[s1 s2]=size(lb);
for i=1:s1
    for j=1:s2
        if lb(i,j)==3|lb(i,j)==4
            A(i,j)=1;
        else
            A(i,j)=0;
        end
    end
end
figure,imshow(A,[]);
title(' cloud Part');
rg1=regionprops(A,'Area');
a=rg1.Area
if a>2
    msgbox('Thick cloud')
else
     msgbox('Thin cloud')
end
elseif outs==2
    msgbox('Snow');
else
    msgbox('Snow with Cloud');
    ima=rgb2gray(I1);
    k=5;
    [mask,mu,v,p]=extract(ima,k);
   [ss1 ss2]=size(mask);
   for i=1:ss1
       for j=1:ss2
           if mask(i,j)==4 | mask(i,j)==5
               AA(i,j)=1;
           else
               AA(i,j)=0;
           end
       end
   end
   figure,imshow(AA,[]);
   title('Snow with Cloud');
   for i=1:ss1
       for j=1:ss2
           if  mask(i,j)==4
               AA(i,j)=1;
           else
               AA(i,j)=0;
           end
       end
   end
   figure,imshow(AA,[]);
   title('Cloud');
   rg1=regionprops(AA,'Area');
a=rg1.Area
if a>2
    msgbox('Thick cloud')
else
     msgbox('Thin cloud')
end

   
end






















